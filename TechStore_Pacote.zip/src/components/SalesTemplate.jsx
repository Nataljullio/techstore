import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart, Star, Zap, Headphones, Smartphone } from "lucide-react";

export default function SalesTemplate() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="w-full bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto flex items-center justify-between p-4">
          <h1 className="text-2xl font-bold text-blue-600">TechStore</h1>
          <Button className="flex items-center gap-2">
            <ShoppingCart size={18} /> Carrinho
          </Button>
        </div>
      </header>
      <section className="bg-blue-600 text-white py-20 text-center">
        <h2 className="text-4xl font-bold mb-4">Eletrônicos Modernos e Acessíveis</h2>
        <p className="text-lg mb-6">LEDs, fones de ouvido, gadgets virais do TikTok e muito mais!</p>
        <Button variant="secondary" size="lg">Explorar Produtos</Button>
      </section>
      <section className="max-w-6xl mx-auto py-16 px-4">
        <h3 className="text-2xl font-semibold mb-8 text-center">Mais Vendidos</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          <Card className="rounded-2xl shadow-md hover:shadow-lg transition">
            <CardContent className="p-4">
              <div className="h-40 bg-gray-200 rounded-xl mb-4 flex items-center justify-center">
                <Zap size={48} className="text-blue-600" />
              </div>
              <h4 className="text-lg font-bold mb-2">Fita LED Inteligente</h4>
              <p className="text-sm text-gray-600 mb-3">Controle por app e Alexa, várias cores e modos.</p>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-blue-600">R$ 79,90</span>
                <Button size="sm">Comprar</Button>
              </div>
            </CardContent>
          </Card>
          <Card className="rounded-2xl shadow-md hover:shadow-lg transition">
            <CardContent className="p-4">
              <div className="h-40 bg-gray-200 rounded-xl mb-4 flex items-center justify-center">
                <Headphones size={48} className="text-blue-600" />
              </div>
              <h4 className="text-lg font-bold mb-2">Fone Bluetooth</h4>
              <p className="text-sm text-gray-600 mb-3">Som de alta qualidade com cancelamento de ruído.</p>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-blue-600">R$ 149,90</span>
                <Button size="sm">Comprar</Button>
              </div>
            </CardContent>
          </Card>
          <Card className="rounded-2xl shadow-md hover:shadow-lg transition">
            <CardContent className="p-4">
              <div className="h-40 bg-gray-200 rounded-xl mb-4 flex items-center justify-center">
                <Smartphone size={48} className="text-blue-600" />
              </div>
              <h4 className="text-lg font-bold mb-2">Mini Projetor Portátil</h4>
              <p className="text-sm text-gray-600 mb-3">Transforme qualquer parede em uma tela gigante.</p>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-blue-600">R$ 299,90</span>
                <Button size="sm">Comprar</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
      <section className="bg-gray-100 py-16">
        <h3 className="text-2xl font-semibold mb-8 text-center">Clientes Satisfeitos</h3>
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6 px-4">
          {["Lucas", "Ana"].map((nome, idx) => (
            <Card key={idx} className="rounded-2xl shadow">
              <CardContent className="p-6 flex flex-col gap-3">
                <div className="flex gap-1 text-yellow-500">
                  {[1,2,3,4,5].map((s) => <Star key={s} size={18} fill="gold" />)}
                </div>
                <p className="text-gray-700 italic">“Comprei um LED e um fone, a entrega foi rápida e a qualidade é excelente!”</p>
                <span className="font-semibold">- {nome}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
      <footer className="bg-blue-700 text-white py-6 text-center mt-12">
        <p>&copy; {new Date().getFullYear()} TechStore. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}