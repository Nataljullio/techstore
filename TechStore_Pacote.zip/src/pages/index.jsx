import SalesTemplate from "../components/SalesTemplate";
import "../styles/globals.css";

export default function Home() {
  return <SalesTemplate />;
}